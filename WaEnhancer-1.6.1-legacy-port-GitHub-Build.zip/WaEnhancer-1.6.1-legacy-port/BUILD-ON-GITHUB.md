# Build WAEnhancer legacy-Xposed variant on GitHub Actions

This source tree was changed to use YukiHook's legacy Xposed 82 runtime. It is **not** a LibXposed API 100 build. Compatibility depends on whether your LSPosed IT framework supports ordinary legacy Xposed modules.

## Build
1. Create a new repository on GitHub.
2. Upload the contents of this folder to the repository (the `.github/workflows/build-legacy.yml` file must be included).
3. Open the repository's **Actions** tab.
4. Select **Build WAEnhancer legacy Xposed** and tap **Run workflow**.
5. When the run finishes, open it and download the artifact named `WAEnhancer-1.6.1-legacy-Xposed-APK`.

The APK produced by this workflow is a debug-signed build. It has not been built or runtime-tested in this environment. Do not install it over the original app unless you are prepared to uninstall the old copy first; signatures may differ.
