package com.wmods.wppenhacer.xposed.features.media

import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import com.wmods.wppenhacer.R
import com.wmods.wppenhacer.xposed.core.Feature
import com.wmods.wppenhacer.xposed.core.WppCore
import com.wmods.wppenhacer.xposed.core.components.StatusItemWpp
import com.wmods.wppenhacer.xposed.core.devkit.Unobfuscator
import com.wmods.wppenhacer.xposed.features.providers.MenuStatusProvider
import com.wmods.wppenhacer.xposed.utils.MimeTypeUtils
import com.wmods.wppenhacer.xposed.utils.Utils
import org.luckypray.dexkit.query.enums.StringMatchType
import java.io.File

class StatusDownload(loader: ClassLoader, preferences: SharedPreferences) :
    Feature(loader, preferences) {

    private val mainHandler = Handler(Looper.getMainLooper())

    override fun doHook() {
        if (!xprefs.getBoolean("downloadstatus", false)) return

        val downloadStatus = object : MenuStatusProvider.Provider {
            override fun addMenu(menu: Menu, statusData: MenuStatusProvider.StatusData): MenuItem? {
                if (menu.findItem(R.string.download) != null) return null
                val item = statusData.currentItem
                if (item.isFromMe) return null
                if (!item.isMediaFile) return null
                return menu.add(0, R.string.download, 0, R.string.download)
            }

            override fun onClick(item: MenuItem, statusData: MenuStatusProvider.StatusData) {
                downloadFile(statusData.currentItem)
            }
        }
        MenuStatusProvider.register(downloadStatus)

        val sharedMenu = object : MenuStatusProvider.Provider {
            override fun addMenu(menu: Menu, statusData: MenuStatusProvider.StatusData): MenuItem? {
                val item = statusData.currentItem
                if (item.isFromMe) return null
                if (menu.findItem(R.string.share_as_status) != null) return null
                return menu.add(0, R.string.share_as_status, 0, R.string.share_as_status)
            }

            override fun onClick(item: MenuItem, statusData: MenuStatusProvider.StatusData) {
                sharedStatus(statusData.currentItem)
            }
        }
        MenuStatusProvider.register(sharedMenu)
    }

    private fun sharedStatus(statusItem: StatusItemWpp) {
        try {
            val fMessage = statusItem.fMessage
            if (!statusItem.isMediaFile) {
                val intent = Intent()
                var clazz: Class<*>
                try {
                    clazz = Unobfuscator.findFirstClassUsingName(
                        classLoader,
                        StringMatchType.EndsWith,
                        "TextStatusComposerActivity"
                    )
                } catch (ignored: Exception) {
                    clazz = Unobfuscator.findFirstClassUsingName(
                        classLoader,
                        StringMatchType.EndsWith,
                        "ConsolidatedStatusComposerActivity"
                    )
                    intent.putExtra("status_composer_mode", 2)
                }
                intent.setClassName(Utils.application.packageName, clazz.name)
                intent.putExtra("android.intent.extra.TEXT", fMessage?.messageStr)
                WppCore.getCurrentActivity()?.startActivity(intent)
                return
            }

            val messageText = fMessage?.messageStr
            Utils.executor.execute {
                try {
                    val file = statusItem.getMediaFile()
                    if (file == null) {
                        Utils.showToast(
                            Utils.getString(R.string.download_not_available),
                            Toast.LENGTH_SHORT
                        )
                        return@execute
                    }
                    val clazz = Unobfuscator.findFirstClassUsingName(
                        classLoader,
                        StringMatchType.EndsWith,
                        "MediaComposerActivity"
                    )

                    mainHandler.post {
                        val intent = Intent()
                        intent.setClassName(Utils.application.packageName, clazz.name)
                        intent.putExtra("jids", arrayListOf("status@broadcast"))
                        intent.putExtra(
                            "android.intent.extra.STREAM",
                            arrayListOf(Uri.fromFile(file))
                        )
                        intent.putExtra("android.intent.extra.TEXT", messageText)
                        WppCore.getCurrentActivity()?.startActivity(intent)
                    }
                } catch (e: Throwable) {
                    Utils.showToast(e.message, Toast.LENGTH_SHORT)
                }
            }

        } catch (e: Throwable) {
            Utils.showToast(e.message, Toast.LENGTH_SHORT)
        }
    }

    private fun downloadFile(statusItem: StatusItemWpp) {
        Utils.executor.execute {
            try {
                val file = statusItem.getMediaFile()
                if (file == null) {
                    Utils.showToast(
                        Utils.getString(R.string.download_not_available),
                        Toast.LENGTH_LONG
                    )
                    return@execute
                }
                val userJid = statusItem.senderJid ?: return@execute
                val fileType = file.name.substring(file.name.lastIndexOf(".") + 1)
                val destination = getStatusDestination(file)
                val name = Utils.generateName(userJid, fileType)
                var savedTo = destination
                val error = Utils.copyFile(file, destination, name) { savedTo = it }

                if (TextUtils.isEmpty(error)) {
                    Utils.showToast(
                        Utils.getString(R.string.saved_to) + savedTo,
                        Toast.LENGTH_SHORT
                    )
                } else {
                    Utils.showToast(
                        "${Utils.getString(R.string.error_when_saving_try_again)}: $error",
                        Toast.LENGTH_SHORT
                    )
                }
            } catch (e: Throwable) {
                Utils.showToast(e.message, Toast.LENGTH_SHORT)
            }
        }
    }

    override fun getPluginName(): String {
        return "Download Status"
    }

    @Throws(Exception::class)
    private fun getStatusDestination(f: File): String {
        val fileName = f.name.lowercase()
        val mimeType = MimeTypeUtils.getMimeTypeFromExtension(fileName)

        val folderPath = when {
            mimeType.contains("video") -> "Status Videos"
            mimeType.contains("image") -> "Status Images"
            mimeType.contains("audio") -> "Status Sounds"
            else -> "Status Media"
        }

        return Utils.getDestination(folderPath)
    }
}
