# Add project specific ProGuard rules here.
# You can control the set of applied configuration files using the
# proguardFiles setting in build.gradle.
#
# For more details, see
#   http://developer.android.com/guide/developing/tools/proguard.html

# If your project uses WebView with JS, uncomment the following
# and specify the fully qualified class name to the JavaScript interface
# class:
#-keepclassmembers class fqcn.of.javascript.interface.for.webview {
#   public *;
#}

# Uncomment this to preserve the line number information for
# debugging stack traces.
-keepattributes SourceFile,LineNumberTable

# If you keep the line number information, uncomment this to
# hide the original source file name.
#-renamesourcefileattribute SourceFile
-dontwarn *
-dontobfuscate
-dontoptimize

# (R fields are accessed and rewritten via reflection)
-keep class com.wmods.wppenhacer.R { *; }
-keep class com.wmods.wppenhacer.R$* { *; }
-keepclassmembers class com.wmods.wppenhacer.R$* {
     public static <fields>;
}

-keepclasseswithmembers class com.wmods.** {
     *;
}

-keepclasseswithmembernames class com.wmods.**

-keepclasseswithmembers class cz.vutbr.** {
     *;
}

-keepclasseswithmembers class com.assemblyai.api.** {
     *;
}
# YukiHookAPI & Xposed Init entrypoints
-keep class com.highcapable.yukihookapi.** { *; }
-keep class io.github.libxposed.** { *; }
-keep class com.wmods.wppenhacer.WppXposed* { *; }
